import customtkinter as ct
import joblib
from PIL import Image
app=ct.CTk()
app.geometry('1600x800')

ct.set_appearance_mode('dark')
ct.set_default_color_theme('blue')
bg_image=ct.CTkImage(dark_image=Image.open('E:/pythonfiles/DIABETES.jpg'),size=(1600,800))
bg_label=ct.CTkLabel(app,image=bg_image,text="")
bg1_label=ct.CTkLabel(app,text="Diabetes Disease Recognisation")
font=ct.CTkFont(bg1_label,20)
bg1_label.pack(padx=20,pady=20)
bg_label.place(x=0,y=0,relwidth=1,relheight=1)

app.title('Diabetes Disease Recognisation')
panel = ct.CTkFrame(app,bg_color='orange')
panel.pack(pady=20)

label1 = ct.CTkLabel(panel, text='pragnencies count:')
label1.grid(row=0, column=0, padx=10, pady=10)

pragnencies = ct.CTkEntry(panel, width=200,bg_color='white')
pragnencies.grid(row=0, column=1, padx=10, pady=10)
label2 = ct.CTkLabel(panel, text='Glucose level:')
label2.grid(row=1, column=0, padx=10, pady=10)

Glucose = ct.CTkEntry(panel, width=200,bg_color='white')
Glucose.grid(row=1, column=1, padx=10, pady=10)
label3 = ct.CTkLabel(panel, text='BloodPressure:')
label3.grid(row=2, column=0, padx=10, pady=10)

BloodPressure = ct.CTkEntry(panel, width=200,bg_color='white')
BloodPressure.grid(row=2, column=1, padx=10, pady=10)
label4 = ct.CTkLabel(panel, text='SkinThickness:')
label4.grid(row=3, column=0, padx=10, pady=10)

SkinThickness = ct.CTkEntry(panel, width=200,bg_color='white')
SkinThickness.grid(row=3, column=1, padx=10, pady=10)
label5 = ct.CTkLabel(panel, text='Insulin level:')
label5.grid(row=4, column=0, padx=10, pady=10)

Insulin = ct.CTkEntry(panel, width=200,bg_color='white')
Insulin.grid(row=4, column=1, padx=10, pady=10)
label6= ct.CTkLabel(panel, text='BMI:')
label6.grid(row=5, column=0, padx=10, pady=10)

BMI= ct.CTkEntry(panel, width=200,bg_color='white')
BMI.grid(row=5, column=1, padx=10, pady=10)
label7 = ct.CTkLabel(panel, text='DiabetesPedigreeFunction:')
label7.grid(row=6, column=0, padx=10, pady=10)

DiabetesPedigreeFunction= ct.CTkEntry(panel, width=200,bg_color='white')
DiabetesPedigreeFunction.grid(row=6, column=1, padx=10, pady=10)
label8 = ct.CTkLabel(panel, text='Age:')
label8.grid(row=7, column=0, padx=10, pady=10)

Age = ct.CTkEntry(panel, width=200,bg_color='white')
Age.grid(row=7, column=1, padx=10, pady=10)
def diabetes_recognise(pragnencies,Glucose,BloodPressure,SkinThickness,Insulin,BMI,DiabetesPedigreeFunction,Age):
    model=joblib.load(r'E:/pythonfiles/diabetes.pkl')
    outcome=model.predict([[pragnencies,Glucose,BloodPressure,SkinThickness,Insulin,BMI,DiabetesPedigreeFunction,Age]])
    panel.pack_forget()
    def Back():
        button1.destroy()
        newpannel.destroy()
        panel.configure(width=500,height=800)
        panel.pack()
    button1=ct.CTkButton(app,text='Back',command=Back)
    button1.place(relx=0.5,rely=0.9,anchor='center')
    if outcome==True:
        newpannel=ct.CTkFrame(app)
        newpannel.pack(pady=20)
        labelo=ct.CTkLabel(newpannel,text='You are having diabetes')
        labelo.pack(pady=20)
    else:
        newpannel=ct.CTkFrame(app)
        newpannel.pack(pady=20)
        labelo=ct.CTkLabel(newpannel,text='You are not having diabetes')
        labelo.pack(pady=20)
     
button=ct.CTkButton(panel,text='submit',command=lambda:diabetes_recognise(pragnencies.get(),Glucose.get(),BloodPressure.get(),SkinThickness.get(),Insulin.get(),BMI.get(),DiabetesPedigreeFunction.get(),Age.get()))
button.grid(row=8,column=1,pady=15)
app.mainloop()
